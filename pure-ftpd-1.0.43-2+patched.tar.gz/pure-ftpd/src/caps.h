#ifndef __CAPS_H__
#define __CAPS_H__ 1

void drop_login_caps(void);
void set_initial_caps(void);

#endif
